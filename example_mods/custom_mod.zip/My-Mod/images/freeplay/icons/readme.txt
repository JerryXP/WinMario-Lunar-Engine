Place your Freeplay Icons in here!
The animation prefixes needs to be "idle" & "confirm"