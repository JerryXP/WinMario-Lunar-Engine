Place your custom album Image!
(it needs to be 262 x 262)

* the album roll text is optional, But the Animation prefixes needs to have "switch" & "idle"